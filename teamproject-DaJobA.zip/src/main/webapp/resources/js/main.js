$("#myCarousel").carousel({
  interval: false
});