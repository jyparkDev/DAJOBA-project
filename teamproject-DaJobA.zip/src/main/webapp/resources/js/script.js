function zipCheck(){
   url = "zipcheck"; 
   window.open(url,"get",
      "toolbar=no,width=350,height=300,top=200,left=300,status=yes,scrollbars=yes,menubar=no");
}

function idCheck(){
   $.ajax({
        type:"POST",
        url:"idcheck",
        data:{
               "member_id":$('#member_id').val()
        },
        success:function(data){  
           //alert($('#member_id').val())
               if($.trim(data)=="y"){
                  if($('#member_id').val()!='y'){ 
                     
                     $('.id.regex').html("사용가능합니다");
                     $('#btnOk').removeAttr("disabled");
                  }
                 }else{
                  if($('#p_id').val()!="n"){
                     
                     $(".id.regex").html("아이디를 변경하세요");
                $('.id.regex').css("color", "red");
                $('#btnOk').attr("disabled", "disabled");
                return;
                      
                  }
               }
            }          
       }) ;
   
}

//동검색
function dongCheck(){
   //alert("c");
   if(zipForm.area3.value === ""){
      alert("검색할 동이름을 입력하시오");
      zipForm.area3.focus();
      return;
   }
   zipForm.submit();
}
   
function allCheck() {
   //아이디 
   if (regForm.member_id.value == "") {
      alert("아이디를 입력하세요!");
      regForm.member_id.focus();
      return;
   };
   var idCheck = /^[a-z0-9]+[a-z0-9]{5,19}$/g;
   if (!idCheck.test(regForm.member_id.value)) {
      alert("아이디는 6~20자의 영문 소문자, 숫자만 사용 가능합니다.");
      regForm.member_id.focus();
      return;
   };
   //중복검사
/*   if (!btnId.visited) {
      alert("아이디 중복체크 하세요.");
      btnId.focus();
   } else {*/


      //비밀번호
      if (regForm.member_pwd.value == "") {
         alert("비밀번호를 입력하세요.");
         regForm.member_pwd.focus();
         return;
      };
      var pwdCheck = /^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{8,20}$/;
      if (!pwdCheck.test(regForm.member_pwd.value)) {
         alert("비밀번호는 8~20자의 영문자+숫자+특수문자 조합으로만 사용 가능합니다.");
         regForm.member_pwd.focus();
         return;
      };
      if (regForm.repasswd.value !== regForm.member_pwd.value) {
         if (regForm.repasswd.value == "") {
            alert("비밀번호를 다시 한번 입력하세요!");
            regForm.repasswd.focus();
            return;
         } else {
            alert("비밀번호 불일치! 비밀번호를 확인하세요!");
            regForm.member_pwd.value = "";
            regForm.repasswd.value = "";
            regForm.member_pwd.focus();
            return;
         }
      };

      //이름 
      if (regForm.member_name.value == "") {
         alert("이름을 입력하세요!");
         regForm.member_name.focus();
         return;
      }
      var nameCheck = /^[가-힣]{2,4}|[a-zA-Z]{2,10}\s[a-zA-Z]{2,10}$/; //한글 또는 영문 이름 //띄어쓰기 가능 (띄어쓰기 불가능:/^[a-zA-Z]+$/)
      if (!nameCheck.test(regForm.member_name.value)) {
         alert("이름은 한글(2자 이상) 또는 영문만 사용 가능합니다. \n (ex. 한글이름 : 폴박,   영문이름 : Paul Park)");
         regForm.member_name.focus();
         return;
      }

      //성별 
      if (!female.checked && !male.checked) { //둘다 미체크시
         alert("성별을 선택하세요.");
         female.focus();
         return;
      }

      //생일
      if (regForm.birth_yy.value == ""
         || regForm.birth_mm.value == ""
         || regForm.birth_dd.value == "") {
         alert("생년월일을 입력하세요!");
         regForm.member_birth.focus();
         return;
      }
      var birthCheck = /^[0-9]+/g; //숫자만 입력하는 정규식
      if (!birthCheck.test(regForm.birth_dd.value)) {
         alert("날짜는 숫자만 사용 가능합니다.");
         regForm.birth_dd.focus();
         return;
      }

      //이메일
      if (regForm.member_email1.value == "") {
         alert("이메일을 입력하세요!");
         regForm.member_email1.focus();
         return;
      }
      var emailCheck = /^[a-z0-9]{1,40}$/g;
      if (!emailCheck.test(regForm.member_email1.value)) {
         alert("이메일은 영문 소문자, 숫자만 사용 가능합니다.");
         regForm.member_email1.focus();
         return;
      }


      //휴대폰번호
      if (regForm.member_phone.value == "") {
         alert("휴대폰번호 입력하세요!");
         regForm.member_phone.focus();
         return;
      }
      var phoneCheck = /^[0-9]+/g; //숫자만 입력하는 정규식
      if (!phoneCheck.test(regForm.member_phone.value)) {
         alert("전화번호는 숫자만 입력할 수 있습니다.");
         regForm.member_phone.focus();
         return;
      }
      var phone2Check = /^01([0|1|6|7|8|9]?)?([0-9]{3,4})?([0-9]{4})$/
      if (!phone2Check.test(regForm.member_phone.value)) {
         alert("전화번호를 다시 한번 확인하세요.(010********)");
         regForm.member_phone.focus();
         return false;
      }

      //주소
      if (regForm.member_address.value == "") {
         alert("주소를 입력하세요!");
         regForm.member_address.focus();
         return;
      }

      //입력 값 전송
      regForm.submit();
   /*}*/
}

function goBack(){
   location.href="main1";
}

function reviewCheck() {
   if (Forminsview.review_id.value == null || Forminsview.review_id.value == "") {
      alert("로그인 후 이용하여 주시기 바랍니다.")
      location.href = "login";
   } else {
      if (Forminsview.review_title.value == "") {
         alert("제목을 입력 해주세요.");
         Forminsview.review_title.focus();
         return;
      } else if(Forminsview.review_rate.value == ""){
         alert("평점을 선택 해주세요.");
         Forminsview.review_rate.focus();
         return;
      } else if(Forminsview.review_cont.value == ""){
         alert("리뷰를 작성 해주세요.");
         Forminsview.review_cont.focus();
         return;
      } else{
      Forminsview.submit();
      }
   }
}

function reviewDeleteCheck(review_no, enter_num, review_category) {
   var result = confirm("정말 삭제 하시겠습니까?");
   if(result){
         alert("삭제되었습니다.");
      location.href="reviewdelete?review_no=" + review_no + "&enter_no="+ enter_num+"&review_category="+review_category;
      //document.getElementById("reviewDelete").setAttribute("href","reviewdelete?review_id=" + arg);
   }
}