package pack.controller.resume;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pack.model.resume.ResumeDto;
import pack.model.resume.ResumeInter;

@Controller
public class ResumeDetail {
	@Autowired
	private ResumeInter inter;
	
	@RequestMapping("detail_re")
	@ResponseBody
	public Map<String, Object> detail(@RequestParam("no") String resume_no) {
		//이력서 번호가 넘어온다.
		Map<String, Object> datas = new HashMap<String, Object>();
		ResumeDto resume = inter.searchResume(resume_no);
		
		datas.put("datas", resume);
//		System.out.println(resume.getResume_cert());
//		System.out.println(resume_no);
		return datas;
	}
}
