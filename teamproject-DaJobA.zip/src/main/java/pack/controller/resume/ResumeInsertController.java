package pack.controller.resume;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import pack.model.resume.ResumeInter;

@Controller
public class ResumeInsertController {
	@Autowired
	private ResumeInter reinter;

	@RequestMapping("resumeinsert")
	public String resumeInsert() {
		return "resume/resumeinsert";
	}

	// 이력서 작성 페이지 값들 받아오는 컨트롤러
	@RequestMapping(value = "resumeinsert", method = RequestMethod.POST)
	public ModelAndView insertResume(HttpSession session, @RequestParam("addexp") String[] resume_exp,
			@RequestParam("addcert") String[] resume_cert, @RequestParam("etc") String[] resume_etc,
			@RequestParam("resume_title") String resume_title, @RequestParam("file") MultipartFile file) {

		ResumeBean bean = new ResumeBean();
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ModelAndView view = new ModelAndView();
		// DB 조건 처리를 위한 세션값 읽기
		String member_id = (String) session.getAttribute("member_id");
		String ss1 = "";
		String ss2 = "";
		String ss3 = "";
		String fileName = file.getOriginalFilename();
		// 이미지 file upload부분
		try {
			inputStream = file.getInputStream();

			// 서버에 이미지 파일 업로드부분
			File newFile = new File(
					"D:/work/wsou/[teamproject-DaJobA]/src/main/webapp/resources/image/resume/" + fileName);
			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			outputStream = new FileOutputStream(newFile);
			int read = 0;
			byte[] bytes = new byte[1024];

			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}
		} catch (Exception e) {
			System.out.println("err : " + e);
		} finally {
			try {
				outputStream.close();
			} catch (Exception e2) {
			}
		}

		// 여러개 들어오는 값들 배열로 문자 처리
		for (int i = 0; i < resume_etc.length; i++) {
			if (i < resume_etc.length - 1) {
				ss1 += resume_etc[i] + ",";
			} else {
				ss1 += resume_etc[i];
			}
		}

		for (int i = 0; i < resume_cert.length; i++) {
			if (i < resume_cert.length - 1) {
				ss2 += resume_cert[i] + ",";
			} else {
				ss2 += resume_cert[i];
			}
		}

		for (int i = 0; i < resume_exp.length; i++) {
			if (i < resume_exp.length - 1) {
				ss3 += resume_exp[i] + ",";
			} else {
				ss3 += resume_exp[i];
			}
		}
		bean.setResume_etc(ss1);
		bean.setResume_cert(ss2);
		bean.setResume_exp(ss3);
		bean.setResume_title(resume_title);
		bean.setResume_img(fileName);
		bean.setMember_id(member_id);

		// DB insert 처리 정상 작동 시 이력서 목록 페이지로 이동, 입력 되지 않았을 시 mainpage로 이동
		boolean b = reinter.insertResume(bean);
		if (b) {
			view.setViewName("redirect:/resumelist");
			return view;
		} else {
			view.setViewName("main1");
			return view;
		}

	}
}
