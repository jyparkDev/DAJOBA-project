package pack.controller.emp;

public class EmpBean {
	private String emp_no,emp_name,emp_readcnt,emp_deadline,enter_num,emp_img;

	public String getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(String emp_no) {
		this.emp_no = emp_no;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_readcnt() {
		return emp_readcnt;
	}

	public void setEmp_readcnt(String emp_readcnt) {
		this.emp_readcnt = emp_readcnt;
	}

	public String getEmp_deadline() {
		return emp_deadline;
	}

	public void setEmp_deadline(String emp_deadline) {
		this.emp_deadline = emp_deadline;
	}

	public String getEnter_num() {
		return enter_num;
	}

	public void setEnter_num(String enter_num) {
		this.enter_num = enter_num;
	}

	public String getEmp_img() {
		return emp_img;
	}

	public void setEmp_img(String emp_img) {
		this.emp_img = emp_img;
	}
	  
	

}
