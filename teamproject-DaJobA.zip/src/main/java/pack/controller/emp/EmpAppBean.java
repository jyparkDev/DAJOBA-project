package pack.controller.emp;

public class EmpAppBean {
	private String member_id, resume_no,emp_no, apply_no;

	public String getMember_id() {
		return member_id;
	}

	public String getApply_no() {
		return apply_no;
	}

	public void setApply_no(String apply_no) {
		this.apply_no = apply_no;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getResume_no() {
		return resume_no;
	}

	public void setResume_no(String resume_no) {
		this.resume_no = resume_no;
	}

	public String getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(String emp_no) {
		this.emp_no = emp_no;
	}
	
	
}
