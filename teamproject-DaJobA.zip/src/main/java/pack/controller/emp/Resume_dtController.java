package pack.controller.emp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpInter;
import pack.model.emp.ApplyDto;

@Controller
public class Resume_dtController {

	@Autowired
	private EmpInter empInter;
	
	@RequestMapping("resume_dt")
	@ResponseBody
	public Map<String, Object> resume(@RequestParam("id") String member_id) {
		
	
		
		List<ApplyDto> resumeDto = empInter.searchList(member_id);
		Map<String, Object> resum = new HashMap<String, Object>();
		
		resum.put("data", resumeDto);
		
		
	
		return resum;
	}
}
