package pack.controller.emp;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpInter;

@Controller
public class EmpapplyController {

	@Autowired
	EmpInter empInter;

	@RequestMapping("emp_apply")
	public ModelAndView apply(HttpSession session, @RequestParam("emp_no") String emp_no,
			@RequestParam("resume_no") String resume_no) {
		String member_id = (String) session.getAttribute("member_id");
		EmpAppBean bean = new EmpAppBean();
		bean.setEmp_no(emp_no);
		bean.setMember_id(member_id);
		bean.setResume_no(resume_no);

		ModelAndView view = new ModelAndView();

		boolean result = empInter.applysuccess(bean);
		if (result) {
			view.addObject("url", "applycheck");
			view.setViewName("message2");
		} else {
			view.setViewName("emp/emp_detail");
		}
		return view;
	}

}
