package pack.controller.emp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpDto;
import pack.model.emp.EmpInter;
import pack.model.emp.Emp_dtDto;
import pack.model.enter.EnterDto;


@Controller
public class EmpDetailController {
	
	@Autowired
	private EmpInter empInter;
	
	@RequestMapping("empdetail")
	public ModelAndView detail(@RequestParam("emp_name")String emp_name) {
		
		Emp_dtDto dt_Dto = empInter.searchOne_emtdt(emp_name);
		EmpDto empDto = empInter.searchOne_emp(emp_name);
		EnterDto enterDto = empInter.searchOne_enter(emp_name);
		empInter.count(emp_name);
		ModelAndView view = new ModelAndView();
		view.addObject("emp",empDto);
		view.addObject("enter",enterDto);
		view.addObject("empdt",dt_Dto);
		view.setViewName("emp/empdetail");
		view.addObject("current_page", "emp");
		return view;
	}
}
