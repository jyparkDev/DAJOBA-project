package pack.controller.member;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import pack.model.member.MemberInter;

@Controller
@SessionAttributes("member_id")
public class LoginController {

	@Autowired
	private MemberInter inter;

	// 화면 전환용
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String login() {
		return "member/login";
	}

	// 로그인 후 세션 부여
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView submitLogin(HttpSession session, MemberBean bean) {
		boolean b = inter.loginCheck(bean); // 아이디 체크

		ModelAndView model = new ModelAndView();
		if (b) {
			session.setAttribute("member_id", bean.getMember_id());
			//model.addObject("member_id", bean.getMember_id());
			model.setViewName("redirect:/main1");
			return model;

		} else {
			model.addObject("url", "login");
			model.addObject("msg", "로그인 실패!! 아이디 또는 비밀번호를 확인하여 주시기 바랍니다.");
			model.setViewName("message");
			return model;

		}
	}

	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logout(@ModelAttribute("member_id") String member_id, SessionStatus session) {
		session.setComplete();
		return "redirect:/main1";
	}
}
