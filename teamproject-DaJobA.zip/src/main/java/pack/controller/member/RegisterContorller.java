package pack.controller.member;

import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.member.MemberInter;
import pack.model.member.ZipcodeDto;
//import pack.service.RegisterCheckService;


@Controller
public class RegisterContorller {
	@Autowired
	private MemberInter inter;
	
	//중복 체크 Ajax 를 위한 Service
	/*
	 * @Autowired p
	 rivate RegisterCheckService service;*/
	
	
	
	//회원가입 화면 띄우기
	@RequestMapping(value="register", method=RequestMethod.GET)
	public String loginMain() {
	      return "member/register";
	   }
	
	//회원가입 성공 실패 여부 검사후 페이지 전환
	@RequestMapping(value="register", method=RequestMethod.POST)
	public ModelAndView loginInsert(MemberBean bean) {
		String newNum = Integer.toString(Integer.parseInt(inter.maxNum()) + 1);
		
		bean.setMember_no(newNum);
		boolean b = inter.memberInsert(bean);
		ModelAndView view = new ModelAndView("message");

		if(b){
			view.addObject("url", "login");
			view.addObject("msg", "회원가입을 축하합니다!");
			return view;
		}else{
			view.addObject("url", "register");
			view.addObject("msg", "회원가입 실패!!");
			return view;

		}
	}
	
	
	//주소체크
	@RequestMapping(value="zipcheck", method=RequestMethod.GET)
	public String zipcheck() {
		return "member/zipcheck";
	}
	
	@RequestMapping(value="zipcheck", method=RequestMethod.POST)
	public ModelAndView setzipcheck(ZipcodeBean bean) {
		ArrayList<ZipcodeDto> list = new ArrayList<ZipcodeDto>();
		list = (ArrayList)inter.zipcodeRead(bean.getArea3());
		ModelAndView model = new ModelAndView("member/zipcheck", "zipdata", list);
		
		return model;
	}
	
	//아이디 검사
	@RequestMapping(value="idcheck", method=RequestMethod.GET)
	public ModelAndView idcheck(@RequestParam("member_id") String member_id) {
		
		ModelAndView model = new ModelAndView("member/idcheck");
		boolean b = inter.checkId(member_id);
		
		model.addObject("result", b);
		model.addObject("member_id", member_id);
		return model;
		
	}
	
	/*
	 * //이메일 중복 검사
	 * 
	 * @RequestMapping(value = "email_check", method = RequestMethod.POST) public
	 * void emailCheck(@RequestParam("member_email") String member_email,
	 * HttpServletResponse response) throws Exception {
	 * service.check_email(member_email, response); }
	 * 
	 * //휴대폰 번호 중복 검사
	 * 
	 * @RequestMapping(value = "phone_check", method = RequestMethod.POST) public
	 * void phoneCheck(@RequestParam("member_phone") String member_phone,
	 * HttpServletResponse response) throws Exception {
	 * service.check_email(member_phone, response); }
	 */
}
