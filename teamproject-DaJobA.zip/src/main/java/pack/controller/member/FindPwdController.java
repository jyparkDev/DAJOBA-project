package pack.controller.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.member.FindPwdInter;

@Controller
public class FindPwdController {
	@Autowired
	private FindPwdInter findInter;
	
	@RequestMapping("find")
	public String goFindPwdPage() {
		
		return "member/find_password";
	}
	
	@RequestMapping("find_password")
	public ModelAndView compare(MemberBean bean) {
		if(bean.getMember_email() == null) {
			bean.setSearchCategory("member_phone");
			bean.setSearchValue(bean.getMember_phone());
		}else if(bean.getMember_phone() == null) {
			bean.setSearchCategory("member_email");
			bean.setSearchValue(bean.getMember_email());
		}
		
		ModelAndView model = new ModelAndView();

		if(findInter.isExist(bean)) {
			model.setViewName("member/change_password");
			model.addObject("id_for_change", bean.getMember_id());
		}else {
			model.addObject("url", "find");
	        model.addObject("msg", "회원정보가 일치 하지 않습니다");
	        model.setViewName("message");
		}
		
		return model;
	}
	
	@RequestMapping("change_password")
	public ModelAndView changePwd(MemberBean bean) {
		boolean b = findInter.changePwd(bean);

		ModelAndView model = new ModelAndView();
		System.out.println(bean.getMember_id());
		System.out.println(bean.getMember_pwd());

		if(b) {
			model.addObject("url", "login");
	        model.addObject("msg", "비밀번호가 변경 되었습니다.다시 로그인해주세요.");
	        model.setViewName("message");
		}else {
			model.addObject("url", "login");
	        model.addObject("msg", "비밀번호가 변경되지 않았습니다.관리자에게 문의주시길 바랍니다.");
	        model.setViewName("message");
		}
		
		
		return model;
	}
}
