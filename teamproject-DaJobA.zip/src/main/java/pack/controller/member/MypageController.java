package pack.controller.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import pack.model.member.MemberDto;
import pack.model.member.MemberInter;


@Controller
//@SessionAttributes("member_id")
public class MypageController { 
	@Autowired
	MemberInter inter;
	
	@RequestMapping("mypage_profile")
	public ModelAndView mypage_main(@RequestParam("member_id") String member_id ) { 
		MemberDto dto = new MemberDto();
		System.out.println(member_id);
		dto = inter.getMember(member_id);
		ModelAndView view = new ModelAndView("mypage/mypage_profile", "dto", dto);
		
		return view;
	   }
	
	
	//회원정보 수정 전 - 비밀번호로 본인여부 확인
	@RequestMapping(value="pwd_check", method=RequestMethod.GET)
	public ModelAndView pwd_check(@RequestParam("member_id") String member_id, @RequestParam("mode") String mode ) {
		ModelAndView model = new ModelAndView("mypage/pwd_check");
		model.addObject("member_id", member_id);
		model.addObject("mode", mode);
		
			return model;
	}
	
	@RequestMapping(value="pwd_check", method=RequestMethod.POST)
	public ModelAndView submitPwd_check(MemberBean bean, @RequestParam("mode") String mode) {
		boolean b = inter.checkPwd(bean); //비밀번호 체크
		System.out.println("id" + bean.getMember_id());
		System.out.println("pwd" + bean.getMember_pwd());
		if(b) {
			//model.setViewName("mypage_profile_update");
			ModelAndView model = new ModelAndView("mypage/pwd_check", "fact", "true"); 
			model.addObject("mode", mode);
			return model;

		}else {
			//model.setViewName("mypage_profile");
			ModelAndView model = new ModelAndView("mypage/pwd_check", "fact", "false"); 
			model.addObject("mode", mode);
			return model;
		}
	}
	
	
	//회원정보 수정 화면 요청
	@RequestMapping(value="mypage_profile_update", method=RequestMethod.GET)
	public ModelAndView mypage_update(@RequestParam("member_id") String member_id) {
		System.out.println(member_id);
		MemberDto dto = new MemberDto();
		dto = inter.getMember(member_id);
		System.out.println(dto.getMember_pwd());
		ModelAndView view = new ModelAndView("mypage/mypage_profile_update", "dto", dto);
		return view;
	}
	
	//회원 정보 수정 
	@RequestMapping(value="mypage_profile_update", method=RequestMethod.POST)
	public ModelAndView mypage_update2(@RequestParam("member_id") String member_id, MemberBean bean) {
		System.out.println(member_id);
		System.out.println(bean.getMember_pwd());
		boolean b = inter.memberUpdate(bean);
//		System.out.println(dto.getMember_pwd());
		ModelAndView view = new ModelAndView();
		
		if(b) {
		MemberDto dto = new MemberDto();
		dto = inter.getMember(member_id);
		view.addObject("dto", dto);
			view.setViewName("mypage/mypage_profile");
			return view;
			
		}else {
			view.addObject("url", "mypage_profile");
			view.addObject("msg", "수정 실패하셨습니다.");
			return view;
		}
	}
	//회원 탈퇴 요청
	@RequestMapping(value="mypage_profile_delete", method=RequestMethod.GET)
	public ModelAndView mypage_delete(MemberBean bean, SessionStatus session) {
		System.out.println(bean);
		boolean b = inter.memberDelete(bean);
		ModelAndView view = new ModelAndView("message");
		if(b) {
			session.setComplete();
			view.addObject("url", "logout");
			view.addObject("msg", "탈퇴성공!");
			return view;
		}else {
			view.setViewName("mypage/mypage_profile");
			return view;
		}
	}
	
	
}


