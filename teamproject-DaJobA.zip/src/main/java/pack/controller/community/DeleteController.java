package pack.controller.community;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pack.model.community.CommunityInter;


@Controller
public class DeleteController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping("delete")
	public String del(
			@RequestParam("community_no") String community_no,
			@RequestParam("page") String page){
		System.out.println(community_no);
		System.out.println(page);
		if(inter.delete(community_no))
			return "redirect:/community?page=" + page;
		else
			return "community/error";
	}
}
