package pack.controller.main;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpDto;
import pack.model.emp.EmpInter;
import pack.model.enter.EnterDaoInter;
import pack.model.enter.EnterDto;

@Controller
public class MainController {
   
   @Autowired
   private EmpInter empInter;
   @Autowired
   private EnterDaoInter inter;
   
   //메인화면 오늘의 채용 + 오늘의 기업  리스트 받기 12:15분
   @RequestMapping("main1")
   public ModelAndView main() {
      ArrayList<EnterDto> list = inter.getEnterToday();
      List<EmpDto> emp = empInter.empAll();
      ModelAndView model = new ModelAndView();
      model.addObject("todaylist", list);
      model.addObject("emp",emp);
      model.setViewName("main1");
      return model;
   }
   
   
   //bottom 약관
   @RequestMapping("main_bottom_1")
   public String main_bottom_1() {
      return "main_bottom_1";
   }
   @RequestMapping("main_bottom_2")
   public String main_bottom_2() {
      return "main_bottom_2";
   }
   @RequestMapping("main_bottom_3")
   public String main_bottom_3() {
      return "main_bottom_3";
   }
   @RequestMapping("main_bottom_4")
   public String main_bottom_4() {
      return "main_bottom_4";
   }
}