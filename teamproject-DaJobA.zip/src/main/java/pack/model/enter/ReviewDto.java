package pack.model.enter;

import java.util.Calendar;

public class ReviewDto {
	private String review_no, review_id,review_title, review_category, 
	review_cont,review_ip,review_date,review_like, review_rate, enter_num;

	public String getReview_no() {
		return review_no;
	}

	public void setReview_no(String review_no) {
		this.review_no = review_no;
	}

	public String getReview_id() {
		return review_id;
	}

	public void setReview_id(String review_id) {
		this.review_id = review_id;
	}

	public String getReview_title() {
		return review_title;
	}

	public void setReview_title(String review_title) {
		this.review_title = review_title;
	}

	public String getReview_category() {
		return review_category;
	}

	public void setReview_category(String review_category) {
		this.review_category = review_category;
	}

	public String getReview_cont() {
		return review_cont;
	}

	public void setReview_cont(String review_cont) {
		this.review_cont = review_cont;
	}

	public String getReview_ip() {
		return review_ip;
	}

	public void setReview_ip(String review_ip) {
		this.review_ip = review_ip;
	}

	public String getReview_date() {
		return review_date;
	}

	public void setReview_date(String review_date) {
		this.review_date = review_date;
	}
	public void setReview_date() {
		Calendar cal = Calendar.getInstance();
		int year =cal.get(Calendar.YEAR);
		int month =cal.get(Calendar.MONTH) + 1;
		int day =cal.get(Calendar.DATE);
		this.review_date = year + "-" + month + "-" + day; 
	}
	public String getReview_like() {
		return review_like;
	}

	public void setReview_like(String review_like) {
		this.review_like = review_like;
	}

	public String getReview_rate() {
		return review_rate;
	}

	public void setReview_rate(String review_rate) {
		this.review_rate = review_rate;
	}

	public String getEnter_num() {
		return enter_num;
	}

	public void setEnter_num(String enter_num) {
		this.enter_num = enter_num;
	}
}
