package pack.model.enter;

public class EnterDto {
	private String enter_no, enter_name, expl, enter_url, enter_industry, enter_img;
	private String enter_review, enter_interview, enter_success, category; //categeory: review category
	private String avg, count;
	
	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getAvg() {
		return avg;
	}

	public void setAvg(String avg) {
		this.avg = avg;
	}

	public String getEnter_url() {
		return enter_url;
	}

	public void setEnter_url(String enter_url) {
		this.enter_url = enter_url;
	}

	public String getEnter_img() {
		return enter_img;
	}

	public void setEnter_img(String enter_img) {
		this.enter_img = enter_img;
	}

	public String getEnter_no() {
		return enter_no;
	}

	public void setEnter_no(String enter_no) {
		this.enter_no = enter_no;
	}

	public String getEnter_name() {
		return enter_name;
	}

	public void setEnter_name(String enter_name) {
		this.enter_name = enter_name;
	}

	public String getExpl() {
		return expl;
	}

	public void setExpl(String expl) {
		this.expl = expl;
	}

	public String getEnter_industry() {
		return enter_industry;
	}

	public void setEnter_industry(String enter_industry) {
		this.enter_industry = enter_industry;
	}

	public String getEnter_review() {
		return enter_review;
	}

	public void setEnter_review(String enter_review) {
		this.enter_review = enter_review;
	}

	public String getEnter_interview() {
		return enter_interview;
	}

	public void setEnter_interview(String enter_interview) {
		this.enter_interview = enter_interview;
	}

	public String getEnter_success() {
		return enter_success;
	}

	public void setEnter_success(String enter_success) {
		this.enter_success = enter_success;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
