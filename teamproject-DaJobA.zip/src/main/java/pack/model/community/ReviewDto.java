package pack.model.community;

public class ReviewDto {
	private String review_no, review_name, review_title, review_category, review_cont, review_cip, review_cdate,
			review_readcnt, review_gnum, review_onum, review_nested, review_rate, enter_num;

	public String getReview_no() {
		return review_no;
	}

	public void setReview_no(String review_no) {
		this.review_no = review_no;
	}

	public String getReview_name() {
		return review_name;
	}

	public void setReview_name(String review_name) {
		this.review_name = review_name;
	}

	public String getReview_title() {
		return review_title;
	}

	public void setReview_title(String review_title) {
		this.review_title = review_title;
	}

	public String getReview_category() {
		return review_category;
	}

	public void setReview_category(String review_category) {
		this.review_category = review_category;
	}

	public String getReview_cont() {
		return review_cont;
	}

	public void setReview_cont(String review_cont) {
		this.review_cont = review_cont;
	}

	public String getReview_cip() {
		return review_cip;
	}

	public void setReview_cip(String review_cip) {
		this.review_cip = review_cip;
	}

	public String getReview_cdate() {
		return review_cdate;
	}

	public void setReview_cdate(String review_cdate) {
		this.review_cdate = review_cdate;
	}

	public String getReview_readcnt() {
		return review_readcnt;
	}

	public void setReview_readcnt(String review_readcnt) {
		this.review_readcnt = review_readcnt;
	}

	public String getReview_gnum() {
		return review_gnum;
	}

	public void setReview_gnum(String review_gnum) {
		this.review_gnum = review_gnum;
	}

	public String getReview_onum() {
		return review_onum;
	}

	public void setReview_onum(String review_onum) {
		this.review_onum = review_onum;
	}

	public String getReview_nested() {
		return review_nested;
	}

	public void setReview_nested(String review_nested) {
		this.review_nested = review_nested;
	}

	public String getReview_rate() {
		return review_rate;
	}

	public void setReview_rate(String review_rate) {
		this.review_rate = review_rate;
	}

	public String getEnter_num() {
		return enter_num;
	}

	public void setEnter_num(String enter_num) {
		this.enter_num = enter_num;
	}
	
	
}
