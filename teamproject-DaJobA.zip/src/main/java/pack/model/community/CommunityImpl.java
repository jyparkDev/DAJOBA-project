package pack.model.community;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pack.controller.community.CommunityBean;


@Repository
public class CommunityImpl extends SqlSessionDaoSupport implements CommunityInter{
	
	@Autowired
	public CommunityImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}
	
	@Override
	public ArrayList<CommunityDto> getList() {
		return (ArrayList)getSqlSession().selectList("selectList");
	}

	@Override
	public ArrayList<CommunityDto> getSearch(CommunityBean bean) {
		return (ArrayList)getSqlSession().selectList("searchList", bean);
	}
	
	@Override
	public int currentNum() {
		// 가장 큰 번호
		if(getSqlSession().selectOne("currentNum") == null) return 0;
		return getSqlSession().selectOne("currentNum");
	}

	@Override
	public int totalCnt() {
		return getSqlSession().selectOne("totalCnt");
	}
	
	@Override
	public boolean insert(CommunityBean bean) {
		int re = getSqlSession().insert("insertData", bean);
		if(re > 0)
			return true;
		else
			return false;
	}
	@Override
	public CommunityDto getDetail(String community_no) {
		return getSqlSession().selectOne("selectOne",community_no);
	}
	/*
	@Override
	public CommunityBean selectForm(String community_no) {
		return getSqlSession().selectOne("selectForm",community_no);
	}
	*/
	
	@Override
	public boolean update(CommunityBean bean) {
		int re= getSqlSession().update("updateData",bean);
		if(re>0)
			return true;
		else
			return false;
	}
	
	@Override
	public boolean updateReadcnt(String community_no) {//조회수 증가
		int re= getSqlSession().update("updateReadcnt",community_no);
		if(re>0)
			return true;
		else
			return false;
	}
	@Override
	public boolean delete(String community_no) {
		int re = getSqlSession().delete("deleteData", community_no);
		if(re > 0)
			return true;
		else
			return false;
	}
	
	@Override
	public String selectPass(String community_no) {
		// 수정용
		return getSqlSession().selectOne("selectPass", community_no);
	}
	
	@Override
	public boolean updateOnum(CommunityBean bean) {
		// 댓글용
				int re = getSqlSession().update("updateOnum", bean);
				if(re > 0)
					return true;
				else
					return false;
	}
	
	@Override
	public boolean insertReply(CommunityBean bean) {
		// 댓글 등록
				int re = getSqlSession().insert("insertReData", bean);
				if(re > 0)
					return true;
				else
					return false;
	}
}
