package pack.model.community;

import java.util.ArrayList;

import pack.controller.community.CommunityBean;


public interface CommunityInter {
	ArrayList<CommunityDto> getList();
	ArrayList<CommunityDto> getSearch(CommunityBean bean);
	
	boolean insert(CommunityBean bean);
	CommunityDto getDetail(String community_no);
	//CommunityBean selectForm(String community_no);
	boolean update(CommunityBean bean);
	boolean delete(String community_no);
	int currentNum();
	int totalCnt();
	boolean updateReadcnt(String community_no);
	String selectPass(String community_no);
	
	boolean updateOnum(CommunityBean bean);
	boolean insertReply(CommunityBean bean);

}
