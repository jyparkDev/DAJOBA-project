package pack.model;

import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

//@Repository("dataSource")
public class MyDataSource extends DriverManagerDataSource {	//db.properties랑 같은 역할
	public MyDataSource() {
		setDriverClassName("org.mariadb.jdbc.Driver");
		setUrl("jdbc:mysql://localhost:3306/DAJOBA");
		setUsername("root");
		setPassword("369369");
	}
}