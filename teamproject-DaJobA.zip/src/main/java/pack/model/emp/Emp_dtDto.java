package pack.model.emp;

public class Emp_dtDto {
	
	private String job,worker,employ,pay,mainwork,applyrequire,preference,emp_num;

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getWorker() {
		return worker;
	}

	public void setWorker(String worker) {
		this.worker = worker;
	}

	public String getEmploy() {
		return employ;
	}

	public void setEmploy(String employ) {
		this.employ = employ;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}

	public String getMainwork() {
		return mainwork;
	}

	public void setMainwork(String mainwork) {
		this.mainwork = mainwork;
	}

	public String getApplyrequire() {
		return applyrequire;
	}

	public void setApplyrequire(String applyrequire) {
		this.applyrequire = applyrequire;
	}

	public String getPreference() {
		return preference;
	}

	public void setPreference(String preference) {
		this.preference = preference;
	}

	public String getEmp_num() {
		return emp_num;
	}

	public void setEmp_num(String emp_num) {
		this.emp_num = emp_num;
	}
	
}
