package pack.model.emp;

public class ApplyDto {

	private String resume_no,resume_title,resume_exp,resume_cert,resume_etc,resume_img,resume_date,member_num;

	public String getResume_no() {
		return resume_no;
	}

	public void setResume_no(String resume_no) {
		this.resume_no = resume_no;
	}

	public String getResume_title() {
		return resume_title;
	}

	public void setResume_title(String resume_title) {
		this.resume_title = resume_title;
	}

	public String getResume_exp() {
		return resume_exp;
	}

	public void setResume_exp(String resume_exp) {
		this.resume_exp = resume_exp;
	}

	public String getResume_cert() {
		return resume_cert;
	}

	public void setResume_cert(String resume_cert) {
		this.resume_cert = resume_cert;
	}

	public String getResume_etc() {
		return resume_etc;
	}

	public void setResume_etc(String resume_etc) {
		this.resume_etc = resume_etc;
	}

	public String getResume_img() {
		return resume_img;
	}

	public void setResume_img(String resume_img) {
		this.resume_img = resume_img;
	}

	public String getResume_date() {
		return resume_date;
	}

	public void setResume_date(String resume_date) {
		this.resume_date = resume_date;
	}

	public String getMember_num() {
		return member_num;
	}

	public void setMember_num(String member_num) {
		this.member_num = member_num;
	}
	
	
}
