package pack.model.member;

public class ApplyCheckDto {
	private String resume_no,emp_name,enter_name,resume_title,enter_no;

	
	
	public String getEnter_no() {
		return enter_no;
	}

	public void setEnter_no(String enter_no) {
		this.enter_no = enter_no;
	}

	public String getResume_no() {
		return resume_no;
	}

	public void setResume_no(String resume_no) {
		this.resume_no = resume_no;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEnter_name() {
		return enter_name;
	}

	public void setEnter_name(String enter_name) {
		this.enter_name = enter_name;
	}

	public String getResume_title() {
		return resume_title;
	}

	public void setResume_title(String resume_title) {
		this.resume_title = resume_title;
	}
	
	
}
