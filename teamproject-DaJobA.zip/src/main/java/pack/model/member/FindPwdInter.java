package pack.model.member;

import pack.controller.member.MemberBean;

public interface FindPwdInter {
	boolean isExist(MemberBean bean);
	boolean changePwd(MemberBean bean);
}
